<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<script type="text/javascript" src="<?php echo e(asset('js/module_js/html2canvas.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
<style>
    #shirtDiv{
		width: 550px;
		height: 750px;
		position: absolute;
		top:0;
		
	}
</style>
</head>

<body>

    
    <div id="capture">
        

        <div  id="pictureOrderConfirmation2" style="top:0;height:350px ;width:auto; background-color: rgb(0, 26, 215);background-size: 100%;background-position: center;
        background-repeat: no-repeat;"><div>
    </div>
   
    
    <script type="text/javascript">
    // var source ="<?php echo e(asset('images/module_images/sareeBody.png')); ?>"
    //    $('.img-status').attr('src',source) ;
    // </script>

    

</body>
</html> <?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/test.blade.php ENDPATH**/ ?>