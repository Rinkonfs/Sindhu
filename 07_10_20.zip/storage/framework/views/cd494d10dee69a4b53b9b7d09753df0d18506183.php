<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/aos.js')); ?>"></script>

<script src="<?php echo e(asset('js/scrollax.min.js')); ?>"></script>


<script src="<?php echo e(asset('js/main.js')); ?>"></script>



<script>
    function readMore(x,y,z) {
  var dots = document.getElementById(x);
  var moreText = document.getElementById(y);
  var btnText = document.getElementById(z);

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}


</script>

<?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/inc/scripts.blade.php ENDPATH**/ ?>