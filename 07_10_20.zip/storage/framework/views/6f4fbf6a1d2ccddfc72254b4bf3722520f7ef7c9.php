

<?php $__env->startSection('dashView'); ?>


<div class="container-fluid">    
    
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('adminDashboard')); ?>">
                <i class="fas fa-arrow-left"></i> Product
            </a>
        </li>
        <li class="breadcrumb-item active collaspe">
           Coupon  
        </li>
    </ol>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div  class="card mb-3" >
                    <div class="card-header" data-toggle="collapse" data-target="#category">
                        Add Category
                        <span style="float:right;" data-toggle="collapse" data-target="#category"><i class="fas fa-minus"></i></span>
                    </div>
                    <form  id="category" class="card-body collapse show" method="POST" action="<?php echo e(route('categoryForm')); ?>">
                     <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Name</label>
                            <div  class="col-sm-10">    
                                <input type="text"  placeholder="Write Category Name" name="cat_name" class="form-control input-lg" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Parent </label>
                            <div  class="col-sm-10">    
                                <select type="text" name="cat_p_id" class="form-control input-lg" required>
                                    <option selected disabled>Select Category</option>
                                    <option value="0" >None</option>
                                    <?php $__currentLoopData = App\Models\Category\productCategory::with('parent')->where('cat_p_id',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_p_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                    
                                    <option value="<?php echo e($cat_p_item->id); ?>"><?php echo e($cat_p_item->cat_name); ?></option>    
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Description</label>
                            <div  class="col-sm-10">  
                                <textarea type="text" name="cat_desc" class="form-control input-lg" ></textarea>
                            </div>      
                        </div>    
                        <div class="text-center">
                            <input type="submit" name="add" class="btn btn-primary" value="Add Category" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header">
                        Category List
                    </div>
                   
                    <div class="card-body">    
                        <div class="table-responsive">    
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>Category Name</th>
                                        <th>Parent Category</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                
                                
                                
                                <tbody>
                                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                            <td><?php echo e($cat->id); ?> </td>
                                            <td><?php echo e($cat->cat_name); ?> </td>

                                            <?php if($cat->cat_p_id != 0): ?>
                                                <td>
                                                    <?php $__currentLoopData = App\Models\Category\productCategory::where('id',$cat->cat_p_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($item->cat_name); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                </td>
                                            <?php else: ?>
                                                    <td style="color:#D3D3D3;">No Parent</td>
                                            <?php endif; ?>
                                       
                                        <td>
                                            
                                                
                                                
                                                <a href="/delete/<?php echo e($cat->id); ?>" style="margin-top:5px;" type="submit" class="btn btn-danger"><i class="fas fa-trash"></i>&nbsp;</a>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                            
                        </div> 
                    </div>       
                </div>       
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/category.blade.php ENDPATH**/ ?>