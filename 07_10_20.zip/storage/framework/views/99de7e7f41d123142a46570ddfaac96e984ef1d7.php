<?php echo $__env->make('inc/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('inc/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(URL::to('home')); ?>">Home</a></span> <span>Cart</span></p>
            <h1 class="mb-0 bread">Shopping Cart</h1>
          </div>
        </div>
      </div>
	</div>

		

		
    	<section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">

					<?php if(session('cart')): ?>
						<?php $total = 0 ?>

						<div class="cart-list">
							<table class="table">
								<thead class="thead-primary">
								  <tr class="text-center">
									<th>&nbsp;</th>
									<th>&nbsp;</th>
									<th>Product</th>
									<th>Price</th>
									<th>Quantity</th>
									<th>Total</th>
								  </tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $total += $details['price'] * $details['quantity'] ?>
	
									<tr class="text-center">
										
										
										
										<td class="product-remove"><a href="#" class="remove-from-cart" data-id="<?php echo e($id); ?>"><i style="color:white" class="icon-close"></i></a></td>	
										<td class="image-prod">
											<div>
												<img class="responsive" width="100px" height="auto" src="<?php echo e(url('/images/'.$details['photo'])); ?>" alt="<?php echo e($details['name']); ?>" >
											</div>
										</td>
										
										<td class="product-name">
											<h3><?php echo e($details['name']); ?></h3>
											<p><?php echo e($details['description']); ?></p>
										</td>
										
										<td class="price">&#2547;<?php echo e($details['price']); ?></td>
										
										<td class="quantity">
											<div class="input-group mb-3">
												<input type="text" name="quantity" class="quantity form-control input-number" value="<?php echo e($details['quantity']); ?>" min="1" max="100">
											</div>
										</td>
										
										<td class="total">&#2547;<?php echo e($details['price'] * $details['quantity']); ?></td>
									  </tr><!-- END TR-->

									  
									  
									  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
								  
								</tbody>
							</table>
						</div>

						<div class="row justify-content-END">
							<div class="col col-lg-5 col-md-6 mt-5 cart-wrap ftco-animate">
								<div class="cart-total mb-3">
									<h3>Cart Totals</h3>
									<p class="d-flex">
										<span>Subtotal</span>
									<span>&#2547;<?php echo e($total); ?></span>
									</p>
									<p class="d-flex">
										<span>Delivery</span>
									<span>Will be added on checkout</span>
									</p>
									
									<hr>
									<p class="d-flex total-price">
										<span>Total</span>
										<span>&#2547;<?php echo e($total); ?></span>
									</p>
								</div>
								<p class="text-center"><a href="<?php echo e(route('users.products.checkout')); ?>" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p>
							</div>
						</div>
							
					<?php else: ?>
							
						<div class="text-center ">Empty Cart</div>
						
					<?php endif; ?>

    				
    			</div>
    		</div>
    		
			</div>
		</section>

		

  <?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <!-- loader -->
	<div id="ftco-loader" class="show fullscreen">
		<svg	class="circular"
				width="48px"
				height="48px">
					<circle	class="path-bg"
							cx="24"
							cy="24"
							r="22"
							fill="none"
							stroke-width="4"
							stroke="#eeeeee"/>
					<circle class="path"
							cx="24"
							cy="24"
							r="22"
							fill="none"
							stroke-width="4"
							stroke-miterlimit="10"
							stroke="#F96D00"/>
		</svg>
	</div>


  <?php echo $__env->make('inc/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>

	  
		$(document).ready(function(){

			// $(".update-cart").click(function (e) {
				//    e.preventDefault();
		 
				//    var ele = $(this);
		 
				// 	$.ajax({
				// 	   url: '<?php echo e(url('/products/update-cart')); ?>',
				// 	   method: "patch",
				// 	   data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id"), quantity: ele.parents("tr").find(".quantity").val()},
				// 	   success: function (response) {
				// 		   window.location.reload();
				// 	   }
				// 	});
				// });
		 
				$(".remove-from-cart").click(function (e) {
					e.preventDefault();
		 
					var ele = $(this);
		 
					
						$.ajax({
							url: '<?php echo e(url('/products/remove-from-cart')); ?>',
							method: "DELETE",
							data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id")},
							success: function (response) {
								window.location.reload();
							}
						});
					
				});

		var quantitiy=0;
		   $('.quantity-right-plus').click(function(e){
		        
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		            
		            $('#quantity').val(quantity + 1);

		          
		            // Increment
		        
		    });

		     $('.quantity-left-minus').click(function(e){
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		      
		            // Increment
		            if(quantity>0){
		            $('#quantity').val(quantity - 1);
		            }
		    });
		    
		});
	</script>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/pages/cart.blade.php ENDPATH**/ ?>