
<?php $__env->startSection('dashView'); ?>

<div class="container-fluid">   
   <ol class="breadcrumb">
      <li class="breadcrumb-item">
          <a href="<?php echo e(route('crud.index')); ?>">
              <i class="fas fa-arrow-left"></i> Product
          </a>
          
      </li>
      <li class="breadcrumb-item active">
          View Product
      </li>
  </ol>
  <div class="card mb-3">
      <div class="card-header">
         Viewing <?php echo e($data->productName); ?>

      </div>
      <div class="card-body row">
            <div class="col-sm-6">
               <img style="width:90%;height:90%;" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($data->image); ?>" class="img-fluid img-thumbnail" />
            </div>
            <div class="col-sm-6">
                  <div class="ls-details">
                     <h1 style="text-align: justified;font-family:sans-serif" id="h1"><?php echo e($data->productName); ?></h1>
                     <h2 id="h2"style="opacity: 0.5">TK <?php echo e($data->productPrice); ?></h2>
                     <p style="text-align: justified;font-family:sans-serif"><?php echo e($data->description); ?></p>
                     <div class="row">
                        <div class="col-sm-2">
                           
                           <div style="display:inline-block;float:left;text-transform: uppercase;">
                              Color:<?php echo e($data->productColor); ?>

                           </div>
                        </div>
                        <div class="col-sm-10">   
                           
                           <div style="display:inline-block;float:left;width:25px;height:25px;border:2px solid grey;background:<?php echo e($data->productColor); ?>;">
                           </div>
                           
                        </div>
                     </div>
                     <h6 style="font-weight: 400">Size: <?php echo e($data->productSize); ?></h6>
                  <div style="margin-top:20%">
                     <h5 >Stock: <?php echo e($data->inStock); ?></h5>
                  </div>   
                  </div>
            </div>
      </div>  
  </div>
</div>


<?php $__env->stopSection(); ?>





	
	






<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/view.blade.php ENDPATH**/ ?>