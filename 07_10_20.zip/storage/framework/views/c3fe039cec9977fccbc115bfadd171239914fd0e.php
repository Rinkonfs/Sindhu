<?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(URL::to('home')); ?>">Home</a></span> <span>Shop</span></p>
            <h1 class="mb-0 bread">Shop</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-8 col-lg-10 order-md-last">
                    <div class="row">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12 col-md-12 col-lg-4 ftco-animate d-flex">
                                <div class="product d-flex flex-column">
                                    <a  href="<?php echo e(route('users.products.show', $product->id)); ?>"
                                        class="img-prod">
                                            <img    class="img-fluid"
                                                    src="<?php echo e(url('/images/'.$product->image)); ?>"
                                                    alt="Sindhu Product Image">
                                            
                                            <div  class="overlay">view
                                            </div>
                                    </a>
                                    <div class="text py-3 pb-4 px-3">
                                        <div class="d-flex">
                                            <div class="cat">
                                                <span><?php echo e($product->category); ?></span>
                                            </div>
                                            <div class="rating">
                                                <p class="text-right mb-0">
                                                    <a href="#"><span class="ion-ios-star-outline"></span></a>
                                                    <a href="#"><span class="ion-ios-star-outline"></span></a>
                                                    <a href="#"><span class="ion-ios-star-outline"></span></a>
                                                    <a href="#"><span class="ion-ios-star-outline"></span></a>
                                                    <a href="#"><span class="ion-ios-star-outline"></span></a>
                                                </p>
                                            </div>
                                        </div>
                                        <h3>
                                            <a href="<?php echo e(route('users.products.show', $product->id)); ?>">
                                                <?php echo e($product->productName); ?>

                                            </a>
                                        </h3>
                                        <div class="pricing">
                                            <p class="price">
                                                <span>
                                                    Tk. <?php echo e($product->productPrice); ?>

                                                </span>
                                            </p>
                                        </div>
                                        <p class="bottom-area d-flex px-3">
                                            <a  style="margin-bottom:100px;" 
                                                href="<?php echo e(route('users.products.add-to-cart', $product->id)); ?>"
                                                class="add-to-cart text-center py-2 mr-1">
                                                    <span>Add to cart <i class="icon-add"></i></span></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
		    		<div class="row mt-5">

                        <div class="col text-center">

                            <div class="block-27">

                                <?php if($products->hasPages()): ?>
                                    <ul>

                                        <?php if($products->onFirstPage()): ?>
                                            <li class="disabled"><a>&lt;</a></li>
                                        <?php else: ?>
                                            <li class="disabled"><a href="<?php echo e($products->previousPageUrl()); ?>" rel="prev">&lt;</a></li>
                                        <?php endif; ?>

                                        <?php if($products->currentPage() > 3): ?>
                                            <li class="hidden-xs"><a href="<?php echo e($products->url(1)); ?>">1</a></li>
                                        <?php endif; ?>

                                        <?php if($products->currentPage() > 4): ?>
                                            <li><span>...</span></li>
                                        <?php endif; ?>



                                            <?php $__currentLoopData = range(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($i >= $products->currentPage() - 2 && $i <= $products->currentPage() + 2): ?>
                                                    <?php if($i == $products->currentPage()): ?>
                                                        <li class="active"><span><?php echo e($i); ?></span></li>
                                                    <?php else: ?>
                                                        <li><a href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a></li>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <?php if($products->currentPage() < $products->lastPage() - 3): ?>
                                                <li><span>...</span></li>
                                            <?php endif; ?>
                                            <?php if($products->currentPage() < $products->lastPage() - 2): ?>
                                                <li class="hidden-xs"><a href="<?php echo e($products->url($products->lastPage())); ?>"><?php echo e($products->lastPage()); ?></a></li>
                                            <?php endif; ?>


                                            
                                            <?php if($products->hasMorePages()): ?>
                                                <li><a href="<?php echo e($products->nextPageUrl()); ?>" rel="next">&gt;</a></li>
                                            <?php else: ?>
                                                <li class="disabled"><a>&gt;</a></li>
                                            <?php endif; ?>

                                    </ul>
                                <?php endif; ?>

                            </div>
                        </div>



		        </div>
		    	</div>

		    	<div class="col-md-4 col-lg-2">
                    <div class="sidebar">
                        <div class="sidebar-box-2">
                            <h2 class="heading">Categories</h2>
                            <div class="fancy-collapse-panel">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <?php $__currentLoopData = App\Models\Category\productCategory::with('child')->where('cat_p_id',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cat_item->child->count()>=0): ?>
                                        <div class="panel-heading" role="tab" id="<?php echo e($cat_item->id); ?>">
                                            <h4 class="panel-title">
                                                <a  data-toggle="collapse"
                                                    data-parent="#accordion"
                                                    href="#<?php echo e($cat_item->cat_name); ?>"
                                                    aria-expanded="true"
                                                    aria-controls="<?php echo e($cat_item->cat_name); ?>">
                                                   <?php echo e($cat_item->cat_name); ?>

                                                </a>
                                            </h4>
                                        </div>
                                        <?php $__currentLoopData = $cat_item->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="<?php echo e($cat_item->cat_name); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="<?php echo e($cat_item->id); ?>">
                                            <div class="panel-body">
                                                <ul><a href="//www.google.com/"><?php echo e($submenu->cat_name); ?></a></ul>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="sidebar-box-2">
                            <h2 class="heading">Price Range</h2>
                            <form method="post" class="colorlib-form-2">
                                <div class="row">
                                    <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="guests">Price from:</label>
                                        <div class="form-field">
                                        <i class="icon icon-arrow-down3"></i>
                                        <select name="people" id="people" class="form-control">
                                            <option value="#">1</option>
                                            <option value="#">200</option>
                                            <option value="#">300</option>
                                            <option value="#">400</option>
                                            <option value="#">1000</option>
                                        </select>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="guests">Price to:</label>
                                        <div class="form-field">
                                        <i class="icon icon-arrow-down3"></i>
                                        <select name="people" id="people" class="form-control">
                                            <option value="#">2000</option>
                                            <option value="#">4000</option>
                                            <option value="#">6000</option>
                                            <option value="#">8000</option>
                                            <option value="#">10000</option>
                                        </select>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
    			</div>
    		</div>
    	</div>
    </section>
    <?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- LOADER -->
    <div  id="ftco-loader"
        class="show fullscreen">
            <svg    class="circular"
                    width="48px"
                    height="48px">
                        <circle class="path-bg"
                                cx="24"
                                cy="24"
                                r="22"
                                fill="none"
                                stroke-width="4"
                                stroke="#eeeeee"/>
                        <circle class="path"
                                cx="24"
                                cy="24"
                                r="22"
                                fill="none"
                                stroke-width="4"
                                stroke-miterlimit="10"
                                stroke="#F96D00"/>
            </svg>
    </div>

  <?php echo $__env->make('inc/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
      function notice(){
        alert("Sorry,there is no product yet in this category");

      }
  </script>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/pages/shop.blade.php ENDPATH**/ ?>