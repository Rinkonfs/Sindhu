

<?php $__env->startSection('dashView'); ?>
<div class="container-fluid">
    
    <div  class="card mb-3" >
        <div class="table-responsive">    
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Client Mobile</th>
                        <th>Quantity</th>
                        <th>Message</th>
                        <th>Design</th>
                        <th>Color</th>
                        <th>Wear Type</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Client Name</th>
                        <th>Client Mobile</th>
                        <th>Quantity</th>
                        <th>Message</th>
                        <th>Design</th>
                        <th>Color</th>
                        <th>Wear Type</th>
                    </tr>
                </tfoot>    
                <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($row->name); ?> </td>
                    <td><?php echo e($row->mobile); ?></td>
                    <td><?php echo e($row->quantity); ?></td>
                    <td><?php echo e($row->message); ?> </td>
                    <td ><img  src="<?php echo e($row->design); ?>" width="32" height="auto"  onclick="style1();"/> </td>
                    <td><div style="height:15px;width:15px;background-color:<?php echo e($row->color); ?>"></div> </td>
                    <td><?php echo e($row->wear_type); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button onclick="style1();">THis is the</button>
            
        </div> 
    </div>
</div> 
<script>
    function style1(){
        showImage('bilder/Almanacka_stor.png');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_pages/customOrder.blade.php ENDPATH**/ ?>