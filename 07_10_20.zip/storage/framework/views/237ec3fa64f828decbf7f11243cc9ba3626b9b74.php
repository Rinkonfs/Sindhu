

<?php $__env->startSection('dashView'); ?>
<div class="container-fluid">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('crud.index')); ?>">
                <i class="fas fa-arrow-left"></i> Product
            </a>
        </li>
        <li class="breadcrumb-item active">
            Edit Product
        </li>
    </ol>       
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="card mb-3"> 
        <div class="card-header">
            <i class="fas fa-gift"></i> Edit Product
        </div>       
        <form class="card-body" method="post" action="<?php echo e(route('crud.update', $data->id)); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <?php echo method_field('PATCH'); ?>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Product Name</label>
                <div  class="col-sm-10"> 
                    <input type="text" name="productName" value="<?php echo e($data->productName); ?>" class="form-control input-lg" required/>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Price </label>
                <div class="col-sm-10">
                    <input type="text" name="productPrice" value="<?php echo e($data->productPrice); ?>" class="form-control input-lg" required/>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Color</label>
                <div class="col-sm-10">
                    <input type="text" name="productColor" value="<?php echo e($data->productColor); ?>" class="form-control input-lg" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Category</label>
                <div class="col-sm-10">
                    <input type="text" name="category" value="<?php echo e($data->category); ?>" class="form-control input-lg" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Size</label>
                <div class="col-sm-10">
                    <input type="text" name="productSize" value="<?php echo e($data->productSize); ?>" class="form-control input-lg" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Description</label>
                <div class="col-sm-10">
                    <input type="text" name="description" value="<?php echo e($data->description); ?>" class="form-control input-lg" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Stock</label>
                <div class="col-sm-10">
                    <input type="text" name="inStock" value="<?php echo e($data->inStock); ?>" class="form-control input-lg" required/>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Select Profile Image</label>
                <div class="col-sm-10">
                    <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($data->image); ?>" class="img-thumbnail" width="300" />
                    <input type="hidden" name="hidden_image" value="<?php echo e($data->image); ?>" />
                    <input type="file" name="image"/>
                </div>
            </div>   
            <div class="text-center">
                <input  type="submit" name="edit" class="btn btn-primary" value="Edit Product" />
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/edit.blade.php ENDPATH**/ ?>