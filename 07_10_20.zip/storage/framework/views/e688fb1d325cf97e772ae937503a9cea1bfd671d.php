

<?php $__env->startSection('dashView'); ?>

    <div class="container-fluid">

        <?php if($message = Session::get('success')): ?>
            <div class = "alert alert-success">
                <p> <?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-shopping-bag "> All Orders</i>
            </div>
            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Order id</th>
                            <th>Order Status</th>
                            <th>Payment Status</th>
                            <th>Payment Method</th>
                            <th>Total Products</th>
                            <th>Total Quantity</th>
                            <th>Total Price</th>
                            <th>Order Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Order id</th>
                            <th>Order Status</th>
                            <th>Payment Status</th>
                            <th>Payment Method</th>
                            <th>Total Products</th>
                            <th>Total Quantity</th>
                            <th>Total Price</th>
                            <th>Order Date</th>
                            <th>Actions</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->order_status); ?></td>
                                <td><?php echo e($order->payment_status); ?></td>
                                <td><?php echo e($order->payment_method); ?></td>
                                <td><?php echo e($productCounter); ?></td>
                                <td><?php echo e($productsQuantityCounter); ?></td>
                                <td><?php echo e($totalCosts); ?></td>
                                <td><?php echo e($order->created_at->format('d-m-y')); ?></td>
                                <td>
                                    <a href= "<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-info"><i class="fas fa-eye"></i> </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo $orders->links(); ?>

                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/admin-orders-index.blade.php ENDPATH**/ ?>