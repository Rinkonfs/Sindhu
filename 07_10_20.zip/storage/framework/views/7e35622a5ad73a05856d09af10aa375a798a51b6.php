

<?php $__env->startSection('dashView'); ?>


<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>
    <div class="container-fluid">    
    
        <?php if($message = Session::get('success')): ?>
        <div class = "alert alert-success">
        <p> <?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-shopping-bag "></i> All Product
                
                <a href="#" title="Add Product" class="btn btn-success" style="float:right;border-radius: 8px;"><i class="fas fa-plus"></i></a>
            </div>
            
            <div class="card-body">    
                <div class="table-responsive">    
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Color</th>
                                <th>Size</th>
                                <th>Description</th>
                                <th>Stock</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Color</th>
                                <th>Size</th>
                                <th>Description</th>
                                <th>Stock</th>
                                <th>Actions</th>
                            </tr>
                        </tfoot>    
                        
                        <tbody>
                            
                            <tr>
                            
                            <td> </td>
                            <td> </td>
                            <td> </td>
                            <td> </td>
                            <td> </td>
                            <td> </td>
                            <td> </td>
                            <td>
                                <a href= "#" class="btn btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href= "#" class="btn btn-warning">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <form action = "#" method="post">
                                    <?php echo csrf_field(); ?>
                                    
                                    <button style="margin-top:5px;" type="submit" class="btn btn-danger">
                                        <i class="fas fa-trash"></i>&nbsp;
                                    </button>
                                </form>    
                            </td>
                            </tr>
                            
                        </tbody>
                    </table>
                    
                </div> 
            </div>       
        </div>    
    </div> 


</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/Order_page.blade.php ENDPATH**/ ?>