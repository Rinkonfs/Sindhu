<?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
body {
  background:#efefef;
  font-size:16px;
  color:#777;
  font-family:sans-serif;
  font-weight:300;
}
#login-box {
  position:relative;
  margin: 10% auto;
  height:400px;
  width:600px;
  background:#fff;
  box-shadow: 0 2px 4px rgba(0,0,0,0.6);
}
.left-box {
  position:absolute;
  top:0;
  left:0;
  box-sizing: border-box;
  padding:40px;
  width:300px;
  height:400px;
}
h1 {
  margin:0 0 20px 0;
  font-weight:300;
  font-size:28px;
}
input[type="text"], input[type="password"] {
  display:block;
  box-sizing:border-box;
  margin-bottom:20px;
  padding:4px;
  width:220px;
  height:32px;
  border:none;
  outline:none;
  border-bottom:1px solid #aaa;
  font-family:sans-serif;
  font-weight:400;
  font-size:15px;
  transition: 0.2s ease;
}
input[type="submit"] {
  margin-bottom:28px;
  width:220px;
  height:32px;
  background:#f44336;
  border:none;
  border-radius:2px;
  color:#fff;
  font-family:sans-serif;
  font-weight:500;
  text-transform:uppercase;
  transition:0.25s ease;
  cursor:pointer;
}
input[type="submit"]:hover,input[type="submit"]:focus {
  background:#ff5722;
  transition: 0.2s ease;
}
.right-box {
  position:absolute;
  top:0;
  right:0;
  box-sizing:border-box;
  padding:40px;
  width:300px;
  height:400px;
  background-image:url(<?php echo e(asset('images/color.jpg')); ?>);
  background-size:cover;
  background-position:center;
}
.or {
  position:absolute;
  top:180px;
  left:280px;
  width:40px;
  height:40px;
  background:#efefef;
  border-radius:50%;
  box-shadow: 0 2px 4px rgba( 0,0,0,0.6);
  line-height:40px;
  text-align:center;
}
.right-box .signinwith {
  display:block;
  margin-bottom:40px;
  font-size:28px;
  color:#fff;
  text-align:center;
  text-shadow:0 2px 4px rgba( 0,0,0,0.6);
}

</style>
</head>

<body>
  <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
  <div id="login-box">
    <form class="left-box" method="POST" action="<?php echo e(route('register')); ?>">
      <?php echo csrf_field(); ?>
      <h1> Sign Up </h1>
      <input  id="name"
              type="text"
              class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              name="name"
              value="<?php echo e(old('name')); ?>"
              required
              autocomplete="name"
              placeholder="Username"
              autofocus/>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input  id="email"
              type="text"
              name="email"
              placeholder="Email"
              class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              value="<?php echo e(old('email')); ?>"
              required
              autocomplete="email"/>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input  id="password"
              type="password"
              name="password"
              placeholder="Password"
              class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              required
              autocomplete="new-password"/>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input  id="password-confirm"
              type="password"
              name="password_confirmation"
              placeholder="Retype Password"
              required
              autocomplete="new-password"/>
      <input  type="submit"
              value="Register"
              name="signup-button"
              placeholder="Sign Up"/>

    </form>
    
    <form class="right-box" method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>
      <span class="signinwith">Login In</span>
      <input  id="email" 
              type="text"
              class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              name="email"
              value="<?php echo e(old('email')); ?>"
              required
              autocomplete="email"
              placeholder="Email"
              autofocus/>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              
      <div>
         <input id="password" 
              type="password"
              name="password"
              placeholder="Password"
              class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              required
              autocomplete="current-password"/>
      </div>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             
      
        <div class="form-check">
          <input  class="form-check-input"
                  type="checkbox"
                  name="remember"
                  id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

          <label class="form-check-label" for="remember" style="color:#141a46;">
            <?php echo e(__('Remember Me')); ?>

          </label>
       </div>
        <input type="submit"
          value="Login"
          name="signup-button"
          placeholder="Sign Up"/>
        <?php if(Route::has('password.request')): ?>
        <a  style="font-size:13px;color:#141a46; font-weight:600;margin-left:20%;" href="<?php echo e(route('password.request')); ?>">
              <?php echo e(__('Forgot Your Password?')); ?>

        </a>
        <?php endif; ?>
    </form>

    <div class="or">OR</div>

  </div>


  <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <?php echo $__env->make('inc.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/auth/register.blade.php ENDPATH**/ ?>