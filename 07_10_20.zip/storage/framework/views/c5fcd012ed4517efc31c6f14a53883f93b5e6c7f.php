<div class="py-1 bg-black">
  <div class="container">
    <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
      <div class="col-lg-12 d-block">
        <div class="row d-flex">
          <div class="col-md pr-4 d-flex topper align-items-center">
            <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
            <span class="text"><a href="tel:+8801766598447">+8801766598447</a></span>
          </div>
          <div class="col-md pr-4 d-flex topper align-items-center">
            <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
            <span class="text">info@sindhustore.com</span>
          </div>
          <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right">
            <span class="text">3-5 Business days delivery &amp; Free Returns</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
        <img src="<?php echo e(asset('images/sindhu_logo.png')); ?>" width="40" height="auto" class="d-inline-block align-top" alt="Sindhu Logo">
      Sindhu Store
      </a>
      <button class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#ftco-nav"
              aria-controls="ftco-nav"
              aria-expanded="false"
              aria-label="Toggle navigation">
        <span class="icon-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active"><a href="<?php echo e(URL::to('/')); ?>" class="nav-link">Home</a></li>
          <li class="nav-item"><a href="<?php echo e(URL::to('/shop')); ?>" class="nav-link">Shop</a></li>
          <li class="nav-item"><a href="<?php echo e(URL::to('/about')); ?>" class="nav-link">About</a></li>
          <li class="nav-item"><a href="<?php echo e(URL::to('/contact')); ?>" class="nav-link">Contact</a></li>
          <li class="nav-item"><a href="<?php echo e(URL::to('/Custom_Order')); ?>" class="nav-link">Custom Order</a></li>


            <?php if(session('status')): ?>
              <div class="alert alert-success" role="alert">
                  <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
          <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item dropdown">
              <a  class="nav-link dropdown-toggle"
                  href="#"
                  id="dropdown04"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false">
                  Account
              </a>
              <div  class="dropdown-menu"
                    aria-labelledby="dropdown04">
                <a  class="dropdown-item"
                    href="<?php echo e(route('login')); ?>">
                      <?php echo e(__('Login')); ?>

                </a>
                <?php if(Route::has('register')): ?>
                  <a  class="dropdown-item" 
                      href="<?php echo e(route('register')); ?>">
                        <?php echo e(__('Register')); ?>

                  </a>
                <?php endif; ?>
              </div>
            </li>
              <?php else: ?>
              <li class="nav-item dropdown">
                <a  id="navbarDropdown"
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                    v-pre>
                      <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <div  class="dropdown-menu dropdown-menu-right"
                      aria-labelledby="navbarDropdown">
                      
                        <a  class="dropdown-item"
                            href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?>

                        </a>
                        <a  class="dropdown-item"
                            href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                              <?php echo e(__('Logout')); ?>

                        </a>
                  <form id="logout-form"
                        action="<?php echo e(route('logout')); ?>"
                        method="POST"
                        style="display: none;">
                          <?php echo csrf_field(); ?>
                  </form>
                </div>
            </li>
          <?php endif; ?>

              <li class="nav-item dropdown cta cta-colored">
                <a  class="nav-link dropdown-toggle cart_a"
                    onclick="myFunction()"
                    id="navbarDropdown">
                    <span class="icon-shopping_cart"></span>
                    <?php echo e(count((array) session('cart'))); ?>

                </a>
         
                <script>
                  function myloadFunction(){
                      document.getElementById("mySidenav").style.display="none";
                  }
                  document.addEventListener("DOMContentLoaded", myloadFunction);
                  function myFunction() {
                    if(screen.width > 768) { 
                      var x = document.getElementById("mySidenav");
                      if(x.style.display === "none") {
                        x.style.display = "block";
                      } 
                      else {
                        x.style.display = "none";
                      }
                    }
                    else{
                      window.location.href = "<?php echo e(url('cart')); ?>"; 
                    }
                  }
                </script>
                
                <div id="mySidenav" class="scroller ">
                  <div>
                    <div class="shopping-cart-header">
                    
                      <div class="shopping-cart-total">
                        <?php $total = 0 ?>
                        <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $total += $details['price'] * $details['quantity'] ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <p>Total: <span>৳<?php echo e($total); ?></span></p>
                      <hr>
                    </div>

                    <?php if(session('cart')): ?>
                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="shopping-cart-items">
                      <li class="cart_li">
                        <img class="cart_img" src="<?php echo e(url('/images/'.$details['photo'])); ?>" />
                        <span class="item-name"><?php echo e($details['name']); ?></span>
                        <span class="item-price">৳ <?php echo e($details['price']); ?></span>
                        <span class="item-quantity"><?php echo e($details['quantity']); ?> Pcs</span>
                      </li>
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                      
                      
                        <div class="cart_button">
                          <a href="<?php echo e(url('cart')); ?>">View all</a>
                        </div>
                      
                  </div>
                </div>
              </li> 
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/inc/nav.blade.php ENDPATH**/ ?>