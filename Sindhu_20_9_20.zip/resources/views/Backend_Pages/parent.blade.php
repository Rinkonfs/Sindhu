   @extends('Backend_Pages.adminDash')

   @section('dashView')
  <div class="container">    
     <br />
     <h3 style="text-align:center">Sindhu Store Admin Panel</h3>
     <br />
     @yield('main')
    </div>
    @endsection
