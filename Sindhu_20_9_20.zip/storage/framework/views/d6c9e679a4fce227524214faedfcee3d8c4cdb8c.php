<?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<!-- Navbar Starts -->
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Navbar Ends -->
<div class="hero-wrap hero-bread" style="background-image: url(<?php echo e(url('images/bg_6.jpg')); ?>);">
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2">Dashboard</span><span style="color:black">> </span><span>View Order</span></p>
                <h1 class="mb-0 bread">Account Detail</h1>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid pt-2 ">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row" style="padding: 50px;">
        <div class="col-lg-2 col-sm-12" >
            <div>
                <h4 >My Account</h4>
                <hr>
                <ul class="list-group">
                    <li>
                        <a href="<?php echo e(route('users.dashboard')); ?>" >
                            Account Details
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.orders.index')); ?>">
                            Order History
                        </a>
                    </li>
                    <li>
                        <a href="#" > Support </a>
                    </li>
                    <li >
                        <a href="#" > Track Order </a>
                    </li>
                <ul>
            </div>        
        </div>
        <div class="col-lg-10 col-sm-12" style="border-left:1px solid #e5e5e5;padding-left:25px;padding-right:25px;">
            <h4> Order Details </h4>
            <hr>
                <table class="table table-dark" >
                    <thead>
                    <tr >
                        <th >Product Name</th>
                        <th >Category</th>
                        <th >Price</th>
                        <th >Color</th>
                        <th >Size</th>
                        <th >Quantity</th>
                        <th >Total Price</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($product['product']->productName); ?></td>
                                
                                <td><?php echo e($product['product']->category); ?></td>
                                <td>&#2547; <?php echo e($product['product']->productPrice); ?></td>
                                <td><?php echo e($product['product']->productColor); ?></td>
                                <td><?php echo e($product['product']->productSize); ?></td>
                                
                                <td><?php echo e($productsQuantity[$loop->index]->product_quantity); ?></td>
                                <td>&#2547; <?php echo e($productsQuantity[$loop->index]->product_quantity * $product['product']->productPrice); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <thead>
                        <tr style="background-color: #B2BEB5">
                            <th></th>
                            <th></th>
                            <th> </th>
                            <th> </th>
                            <th> </th>
                            <th> <b><h4>Total</b></h4></th>
                            <th><h4>&#2547; <?php echo e($totalCosts); ?></h4></th>
                        </tr>
                        </thead>
                </table>
                
                
                    
                    
                    
        </div>
    </div>
</div>
<!-- footer Starts-->
<?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- footer Ends-->

<!-- loader -->
<div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
        <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
    </svg>
</div>
<!-- Java Scripts -->
<?php echo $__env->make('inc/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/pages/users-order-show.blade.php ENDPATH**/ ?>