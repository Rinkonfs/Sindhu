

<?php $__env->startSection('dashView'); ?>

<div class="container-fluid">    
    
    <?php if($message = Session::get('success')): ?>
    <div class = "alert alert-success">
    <p> <?php echo e($message); ?></p>
    </div>
    <?php endif; ?>
    <div class="card mb-3">
        <div class="card-header">
            <i class="fas fa-shopping-bag "></i> All Product
            <a href="<?php echo e(route('crud.create')); ?>" title="Add Product" class="btn btn-success" style="float:right;border-radius: 8px;"><i class="fas fa-plus"></i></a>
        </div>
        
        <div class="card-body">    
            <div class="table-responsive">    
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Price(BDT)</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Category</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Price(BDT)</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Category</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>    
                    
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($row->image); ?>" class="img-thumbnail" width="75" /></td>
                        <td><?php echo e($row->productName); ?></td>
                        <td>&#2547;<?php echo e($row->productPrice); ?></td>
                        <td><div style="display:inline-block;margin-top:10px;background:<?php echo e($row->productColor); ?>;width:20px;height:20px;border-radius:5px;border:2px solid black;" title="<?php echo e($row->productColor); ?>"></div></td>
                        <td><?php echo e($row->productSize); ?></td>
                        <td><?php echo e($row->category); ?></td>
                        <td><?php echo e($row->inStock); ?></td>
                        <td>
                        <a href= " <?php echo e(route ('crud.show', $row->id)); ?>" class="btn btn-info"><i class="fas fa-eye"></i> </a>
                        <a href= " <?php echo e(route ('crud.edit', $row->id)); ?>" class="btn btn-warning"><i class="fas fa-pen"></i> </a>
                        <form action = "<?php echo e(route ('crud.destroy', $row->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button style="margin-top:5px;" type="submit" class="btn btn-danger"><i class="fas fa-trash"></i>&nbsp;</button>
                        </form>    
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $data->links(); ?>

            </div> 
        </div>       
    </div>    
</div> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/index.blade.php ENDPATH**/ ?>