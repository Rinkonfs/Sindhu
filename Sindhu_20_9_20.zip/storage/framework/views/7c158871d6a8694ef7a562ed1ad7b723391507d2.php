

<?php $__env->startSection('dashView'); ?>

    <div class="container-fluid">

        <?php if($message = Session::get('success')): ?>
            <div class = "alert alert-success">
                <p> <?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-shopping-bag "> Order Show</i>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Image</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Image</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                        </tr>
                        </tfoot>
                        <tbody>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($product['product']->productName); ?></td>
                                <td><?php echo e($product['product']->description); ?></td>
                                <td><?php echo e($product['product']->category); ?></td>
                                <td><?php echo e($product['product']->productPrice); ?></td>
                                <td><?php echo e($product['product']->productColor); ?></td>
                                <td><?php echo e($product['product']->productSize); ?></td>
                                <td><?php echo e($product['product']->image); ?></td>
                                <td><?php echo e($productsQuantity[$loop->index]->product_quantity); ?></td>
                                <td><?php echo e($productsQuantity[$loop->index]->product_quantity * $product['product']->productPrice); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <div class="text-center"><h5><span class="text-danger">Total Costs:</span> Tk. <?php echo e($totalCosts); ?></h5></div>
            </div>
        </div>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-shopping-bag "> Order By</i>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Street</th>
                                <th>Apartment</th>
                                <th>City</th>
                                <th>Post Code</th>
                                <th>Country</th>
                            </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e($user->address->street); ?></td>
                                    <td><?php echo e($user->address->apartment); ?></td>
                                    <td><?php echo e($user->address->city); ?></td>
                                    <td><?php echo e($user->address->post_code); ?></td>
                                    <td><?php echo e($user->address->country); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-shopping-bag "> Order Status</i>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Order Status</th>
                                <th>Payment Status</th>
                                <th>Payment Method</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <td><?php echo e($order->order_status); ?></td>
                                <td><?php echo e($order->payment_status); ?></td>
                                <td><?php echo e($order->payment_method); ?></td>
                                <td><div><button class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal">Update</button></div></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>

    <!-- Order Status Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Order Status</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('put')); ?>


                    <div class="modal-body">

                        <p class="text-danger"><span class="text-dark">Order status:</span> <?php echo e($order->order_status); ?></p>
                        <label for="order-status">Change status:</label>
                        <select id="order-status" name="order_status">

                            <option <?php if( $order->order_status == 'Pending'): ?> selected disabled <?php endif; ?> value="Pending">Pending</option>
                            <option <?php if( $order->order_status == 'Processing'): ?> selected disabled <?php endif; ?> value="Processing">Processing</option>
                            <option <?php if( $order->order_status == 'Delivered'): ?> selected disabled <?php endif; ?> value="Delivered">Delivered</option>

                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info btn-sm">Update changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/admin-orders-show.blade.php ENDPATH**/ ?>