<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<script type="text/javascript" src="<?php echo e(asset('js/module_js/html2canvas.js')); ?>"></script>
<style>
    #shirtDiv{
		/* width: 550px;
		height: 750px;
		position: absolute;
		top:0; */
		/* background-color: rgb(255, 255, 255); */
		background: url("<?php echo e(URL::to('/')); ?>/images/module_images/sareeBody.png");
		/* background-blend-mode: multiply; */
		/* background-size: 100%;
		background-position: center;
		background-repeat: no-repeat; */
	}
</style>
</head>

<body>



    <div id="capture" style="padding: 10px; background: #f5da55">
        <div id="shirtDiv">
            <img src="<?php echo e(URL::to('/')); ?>/images/module_images/icon/logo1.png" height="150px" width="150px" alt=""/>
        </div>
        <h4 style="color: #000; ">Hello world!</h4>
        <img src="<?php echo e(URL::to('/')); ?>/images/module_images/icon/logo1.png" height="150px" width="150px" alt=""/>
        <img src="<?php echo e(URL::to('/')); ?>/images/module_images/icon/logo1.png" height="150px" width="150px" alt=""/>
        <img src="<?php echo e(URL::to('/')); ?>/images/module_images/icon/logo1.png" height="150px" width="150px" alt=""/>
    </div>
    <button style="margin: 1000px" onclick="shit()">CLICK ME</button>
    
<script>

function shit(){
    html2canvas(document.getElementById("capture")).then(canvas => {
        
        //canvas2image.saveAsPNG(canvas);	
        var theimage9 = canvas.toDataURL("image/png", 0.9);
        console.log(theimage9);
        //document.body.appendChild(canvas)
    });
}
    



</script>    

</body>
</html> <?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/test.blade.php ENDPATH**/ ?>