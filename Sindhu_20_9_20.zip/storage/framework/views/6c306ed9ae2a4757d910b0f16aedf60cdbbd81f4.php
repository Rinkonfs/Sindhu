<?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<!-- Navbar Starts -->
    <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Navbar Ends -->
<div class="hero-wrap hero-bread" style="background-image: url(<?php echo e(url('images/bg_6.jpg')); ?>);">
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2">Dashboard</span><span style="color:black">> </span><span>Account Details</span></p>
                <h1 class="mb-0 bread">Dashboard</h1>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid pt-2">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
        <div class="row" style="padding: 50px;">
            <div class="col-lg-2 col-sm-12" >
                <div>
                    <h4 >My Account</h4>
                    <hr>
                    <ul class="list-group">
                        <li>
                            <a href="<?php echo e(route('users.dashboard')); ?>" >
                                Account Details
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('users.orders.index')); ?>">
                                Order History
                            </a>
                        </li>
                        <li>
                            <a href="#" > Support </a>
                        </li>
                        <li >
                            <a href="#" > Track Order </a>
                        </li>
                    <ul>
                </div>        
            </div>
            <div class="col-lg-10 col-sm-12" style="border-left:1px solid #e5e5e5;padding-left:25px;padding-right:25px;">
                <h4>Account Details</h4>
                <hr>
                <div id="accountDetail">
                    <form action="<?php echo e(route('users.profile.update', Auth::id())); ?>" method="post"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                          <fieldset class="col-sm-6 form-group">
                            <div class="form-group">
                              <label class="form-control-label" for="ownername">Full name</label>
                              <input required name="name" <?php if(Auth::user()): ?> value="<?php echo e(Auth::user()->name); ?>"<?php endif; ?> class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ownername" placeholder="Your Name" type="text">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- form-group -->
                      
                            <div class="form-group">
                              <label class="form-control-label" for="owneremail">Email address</label>
                              <input required name="email" <?php if(Auth::user()): ?> value="<?php echo e(Auth::user()->email); ?>"<?php endif; ?> aria-describedby="emailHelp" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="owneremail" placeholder="Enter email" type="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- form-group -->
                          </fieldset>
                          <!-- fieldset -->
                      
                          <fieldset class="form-group col-sm-6">
                            
                            <div class="form-group">
                              <label class="form-control-label" for="phone">Phone</label>
                              <input required name="phone" <?php if(Auth::user()): ?> value="<?php echo e(Auth::user()->phone); ?>"<?php endif; ?> class="form-control  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" placeholder="Your phone number" type="text">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                              <div class="form-group">
                                  <label class="form-control-label" for="password">Password</label>
                                  <input name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Enter new password" type="password">
                                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            <!-- form-group -->

                          </fieldset>
                       
                        <button class="btn btn-primary" type="submit">Submit</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>


    <?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Footer -->


<!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
        <svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
        </svg>
    </div>
<!-- Java Scripts -->
    <?php echo $__env->make('inc/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>