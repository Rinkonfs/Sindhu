<?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Checkout</span></p>
            <h1 class="mb-0 bread">Checkout</h1>
          </div>
        </div>
      </div>
	</div>
	
	<?php if(session('cart')): ?>
	
	<section class="ftco-section">
		<div class="container">
		<?php if(\Session::has('error')): ?>
			<div class="alert alert-danger">
				<ul>
					<p><?php echo \Session::get('error'); ?></p>
				</ul>
			</div>
		<?php elseif(\Session::has('success')): ?>	
		<div class="alert alert-success">
			<ul>
				<p><?php echo \Session::get('success'); ?></p>
			</ul>
		</div>
		<?php endif; ?>
		  <div class="row justify-content-center">
			
				<div class="col-xl-10 ftco-animate">
				  <form method="post" action="<?php echo e(route('users.orders.create')); ?>" class="billing-form"  enctype="multipart/form-data">
					  <?php echo csrf_field(); ?>
					  <h3 class="mb-4 billing-heading">Billing Details</h3>
					  <div class="row align-items-end">
							<div class="col-md-6">
							  <div class="form-group">
								  <label for="firstname">First Name <span class="text-danger">*</span></label>
								  <input name="first_name" required type="text" class="form-control" placeholder="Enter your first name" <?php if(Auth::user()): ?>value="<?php echo e(Auth::user()->name); ?>"<?php endif; ?>>

							  </div>
						  </div>
							
						  <div class="col-md-6">
							  <div class="form-group">
								  <label for="lastname">Last Name <span class="text-danger">*</span></label>
								  <input name="last_name" required type="text" class="form-control" placeholder="Enter your last name" <?php if(Auth::user()): ?>value="<?php echo e(Auth::user()->name); ?>"<?php endif; ?>>
							  </div>
						  </div>

						  <div class="w-100"></div>
							  <div class="col-md-12">
								  <div class="form-group">
									  <label for="country">State / Country <span class="text-danger">*</span></label>
									  <div class="select-wrap">
											<div class="icon"><span class="ion-ios-arrow-down"></span></div>
										  <select required name="country" id="" class="form-control">
											  <?php if(Auth::user() and Auth::user()->address ): ?><option value="<?php echo e(Auth::user()->address->country); ?>" selected ><?php echo e(Auth::user()->address->country); ?></option><?php endif; ?>
											  <option value="Bangladesh">Bangladesh</option>
											  <option value="India">India</option>
											  <option value="Nepal">Nepal</option>
											  <option value="Pakistan">Pakistan</option>
											 <select>
									  </div>
								  </div>
							  </div>
							  
							  <div class="w-100"></div>
							  
							  <div class="col-md-6">
								  <div class="form-group">
									  <label for="streetaddress">Street Address <span class="text-danger">*</span></label>
										<input name="street" <?php if(Auth::user() and Auth::user()->address ): ?>value="<?php echo e(Auth::user()->address->street); ?>"<?php endif; ?> required type="text" class="form-control" placeholder="House number and street name">
								  </div>
							  </div>
							  
							  <div class="col-md-6">
								  <div class="form-group">
										<input name="apartment" <?php if(Auth::user() and Auth::user()->address ): ?>value="<?php echo e(Auth::user()->address->apartment); ?>"<?php endif; ?> type="text" class="form-control" placeholder="Appartment, suite, unit etc: (optional)">
								  </div>
							  </div>
				  
							  <div class="w-100"></div>
							  
							  <div class="col-md-6">
								  <div class="form-group">
									  <label for="towncity">Town / City <span class="text-danger">*</span></label>
										<input name="city" <?php if(Auth::user() and Auth::user()->address ): ?>value="<?php echo e(Auth::user()->address->city); ?>"<?php endif; ?> required type="text" class="form-control" placeholder="Your city">
								  </div>
							  </div>
				  
							  <div class="col-md-6">
					  
								  <div class="form-group">
						  
									  <label for="postcodezip">Postcode / ZIP <span class="text-danger">*</span></label>
					
									  <input name="post_code" <?php if(Auth::user() and Auth::user()->address ): ?>value="<?php echo e(Auth::user()->address->post_code); ?>"<?php endif; ?> required type="text" class="form-control" placeholder="Area postal code">
				  
								  </div>
				  
							  </div>
				  
							  <div class="w-100"></div>
				  
							  <div class="col-md-6">
				  
								  <div class="form-group">
					  
									  <label for="phone">Phone <span class="text-danger">*</span></label>
					
									  <input name="phone" <?php if(Auth::user()): ?>value="<?php echo e(Auth::user()->phone); ?>"<?php endif; ?> required type="text" class="form-control" placeholder="Your phone number">
				  
								  </div>
				
							  </div>
				
							  <div class="col-md-6">
				  
								  <div class="form-group">
					  
									  <label for="emailaddress">Email Address <span class="text-danger">*</span></label>
					
									  <input name="email" <?php if(Auth::user()): ?>value="<?php echo e(Auth::user()->email); ?>"<?php endif; ?> required type="text" class="form-control" placeholder="Your email address">
				  
								  </div>
			  
							  </div>
								
								<div class="w-100"></div>

								<?php if(!Auth::user()): ?>
							  <div class="col-md-12">

								  <div class="form-group mt-4">
									  <div class="radio">
										  <label class="mr-3"><input checked type="radio" name="optradio"> Create an Account? </label>
										  <label class="mr-3 text-danger"> Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a> </label>
									  </div>
									  <div class="radio">
										<label class="mr-3 text-info"> *To recieve discounts and promotional benefits login into your account or <a href="<?php echo e(route('register')); ?>">Sign Up</a> 
										
									</div>
								  </div>
			  
							  </div>
									<?php endif; ?>
			  
						  </div>
			
							<?php $total = 0 ?>

							<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $total += $details['price'] * $details['quantity'] ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<div class="row mt-5 pt-3 d-flex">
							<div class="col-md-6 d-flex">
								<div class="cart-detail cart-total bg-light p-3 p-md-4">
									<h3 class="billing-heading mb-4">Cart Total</h3>
									<p class="d-flex">
											  <span>Subtotal</span>
											  <span>&#2547; <?php echo e($total); ?></span>
										  </p>
										  <p class="d-flex">
											  <span>Delivery</span>
											  <span>&#2547; <?php echo e($deliveryCharge ?? '100'); ?></span>
											  
										  </p>
										  <hr>
										  <p class="d-flex">
											<span>Subtotal + Delivery</span>
											<span>&#2547; <?php echo e($total + $deliveryCharge); ?></span>
											
										</p>
										  <p class="d-flex">
											  <span>Discount</span>
											  <?php if( session('discount') ): ?>  
											  	<span>- &#2547; <?php echo e(session('discount')); ?></span>
											  <?php else: ?>
											  	<span>&#2547; 0.00</span>
											  <?php endif; ?>
										  </p>
										  <hr>
										  <p class="d-flex total-price">
											  <span>Total</span>
											  <?php if(session('totalAmount')): ?> 
											  	<span>&#2547; <?php echo e(session('totalAmount')); ?></span>
											  <?php else: ?>
											  	<span>&#2547; <?php echo e($total + $deliveryCharge); ?></span>
											  <?php endif; ?>
										  </p>
										  </div>
							</div>
							<div class="col-md-6">
								<div class="cart-detail bg-light p-3 p-md-4">
									<h3 class="billing-heading mb-4">Payment Method</h3>

											  <div class="form-group">
												  <div class="col-md-12">
													  <div class="radio">
														 <label><input type="radio" name="optradio" value ="bKash" class="mr-2" required> bKash</label>
													  </div>
												  </div>
											  </div>
											<div class="form-group">
												<div class="col-md-12">
													<div class="radio">
														<label><input type="radio" name="optradio" value ="Cash On Delivery" class="mr-2" required> Cash On Delivery</label>
													</div>
												</div>
											</div>
											  <div class="form-group">
												  <div class="col-md-12">
						   							  <div class="checkbox">
														 <label><input name="termsCheckbox" type="checkbox" value="" class="mr-2" required> I have read and accept the terms and conditions</label>
													  </div>
												  </div>
											  </div>
											<button name="orderPlaceButton" id="submitBtn" class="btn btn-primary py-3 px-4" type="submit">Place an order</button>
									</div>
								</div>
							</div>
				  </form><!-- END -->
				  
				<div class="row">	
				  <div class="col-6">
						<?php if(Auth::user()): ?>
							<form  style="width:100%;margin-top:10px;text-align:center;" method="POST" action="<?php echo e(route('coupon.userinput')); ?>" >
							<?php echo csrf_field(); ?>
									<input style="border-radius:10px;" name="user_coupon_code" type="text" placeholder="Coupon Value" required>
									<input class="btn btn-primary" type="submit" value="Add Coupon" >
							</form>
							<?php endif; ?>
					</div>
				</div>		
				  
		</div> <!-- .col-md-8 -->
	  </div>
	</div>
  </section> <!-- .section -->
						
	<?php else: ?>
		<section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ftco-animate">
							
						<div class="billing-heading text-center">Empty Cart</div>
						
					</div>
				</div>
			
			</div>
		</section>

	<?php endif; ?>

    
		
	<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <?php echo $__env->make('inc.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
		$(document).ready(function(){

		var quantitiy=0;
		   $('.quantity-right-plus').click(function(e){
		        
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		            
		            $('#quantity').val(quantity + 1);

		          
		            // Increment
		        
		    });

		     $('.quantity-left-minus').click(function(e){
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		      
		            // Increment
		            if(quantity>0){
		            $('#quantity').val(quantity - 1);
		            }
		    });
		    
		});
		// var termsBtn=document.getElementsByName('termsCheckbox');
		//  var orderBtn= document.getElementsByName('orderPlaceButton');

		function UnlockButton(){
			if(document.getElementByName("termsCheckbox").checked == true)
			{
				document.getElementById("submitBtn").disabled = false;
			}
			else{
				document.getElementById("submitBtn").disabled  = true;
			}
			return true;
		}
		
	</script>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/pages/checkout.blade.php ENDPATH**/ ?>