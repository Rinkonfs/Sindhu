
<?php $__env->startSection('dashView'); ?>

<div class="container-fluid">    
    
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('crud.index')); ?>">
                <i class="fas fa-arrow-left"></i> Product
            </a>
        </li>
        <li class="breadcrumb-item active">
            Add Product
        </li>
    </ol>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
   <div class="card mb-3">
        <div class="card-header">
            <i class="fas fa-gift"></i> Add Product
        </div>
        <form class="card-body" method="post" action="<?php echo e(route('crud.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Product Name </label>
                <div  class="col-sm-10">    
                    <input type="text" name="productName" class="form-control input-lg" required />
                </div>
            </div>
            <div class="form-group row">
                <label  class="col-sm-2 col-form-label">Price</label>
                <div class="col-sm-10">
                    <input type="number" name="productPrice" class="form-control input-lg" required/>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Color</label>
                <div  class="col-sm-10">  
                    <input type="text" name="productColor" class="form-control input-lg" required/>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Size</label>
                <div  class="col-sm-8">  
                    <input type="text" name="productSize" class="form-control input-lg" required />
                </div>
                <div  class="col-sm-2">  
                    <select type="text" name="inStock" class="form-control input-lg">
                        <option value="1">For children</option>
                        <option value="0">For Adult</option> 
                    </select>
                </div>  
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Product Category </label>
                <div  class="col-sm-10">    
                    <select type="text" name="category" class="form-control input-lg" required>
                        <option selected disabled>Select Category</option>
                        <?php $__currentLoopData = App\Models\Category\productCategory::with('child')->where('cat_p_id',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <?php if($cat_item->child->count()>0): ?>
                            <option value="<?php echo e($cat_item->cat_name); ?>"><?php echo e($cat_item->cat_name); ?></option>    
                            <?php $__currentLoopData = $cat_item->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($submenu->cat_name); ?>"> --<?php echo e($submenu->cat_name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php endif; ?>
                        <?php if($cat_item->child->count()==0): ?>
                           <option value="<?php echo e($cat_item->cat_name); ?>"><?php echo e($cat_item->cat_name); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Product Desctiption</label>
                <div  class="col-sm-10">  
                    <textarea type="text" name="description" class="form-control input-lg" required></textarea>
                </div>      
            </div>    
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Stock</label>
                <div  class="col-sm-10">
                    <select type="text" name="inStock" class="form-control input-lg" required>
                        <option value="1">In Stock</option>
                        <option value="0">Out Of Stock</option> 
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Product Image</label>
                <div  class="col-sm-10">  
                    <input type="file" name="image" accept="image/x-png,image/gif,image/jpeg" required/>
                </div>
            </div>
            <div class="text-center">
                <input type="submit" name="add" class="btn btn-primary" value="Add Product" />
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend_Pages.adminDash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sindhu\resources\views/Backend_Pages/create.blade.php ENDPATH**/ ?>